/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.polidea.rxandroidble2;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.polidea.rxandroidble2";
  public static final String BUILD_TYPE = "release";
}
